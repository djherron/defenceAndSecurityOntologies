# README

The two `saref` ontologies, one for buildings, one for cities, overlap strongly with the `smart-buildings` and `smart-cities` clusters, respectively. They should be regarded as members of those two clusters as well as `digital-twins`.  It might be simpler to ignore the digital-twins cluster for now and, instead, place the `saref4bldgMerge.ttl` in `smart-buildings` and `saref4cityMerge.ttl` in `smart-cities`




